using DemoApp.Models;
using Microsoft.AspNetCore.Mvc;

namespace DemoApp.Controllers;

public class HomeController : Controller
{
    public IActionResult Display2([FromServices] EmpDbContext site) 
    {
        return View(new Admin());
    }
    
    public IActionResult RegisterE([FromServices] EmpDbContext site) 
    {
        var selection = from emp in site.Employees
                        select new EmpInfo 
                        {
                            EId = emp.Id,
                            EName = emp.ename,
                            ESalary = emp.sal,
                            EAge = emp.age,
                            DeptId = emp.DeptId
                        };
        return View(selection.ToList()); 
    }

    public IActionResult AddE()
    {
        return View(new Employee());
    }

    [HttpPost]
    public IActionResult AddE([FromServices] EmpDbContext site, Employee input)
    {
       
            site.Employees.Add(input);
            //emp.Employeess.Add(new Employee());
            site.SaveChanges();
            return RedirectToAction("RegisterE");
       
    }


    public IActionResult Delete()
    {
        return View(new Employee());
    }

    [HttpPost]
    public IActionResult Delete([FromServices] EmpDbContext site, Employee input)
    {
        if(ModelState.IsValid)
        {
       
            site.Employees.Remove(input);
            //emp.Employeess.Add(new Employee());
            site.SaveChanges();
            return RedirectToAction("RegisterE");
        }
        return Delete();
  
    }

    public IActionResult Update()
    {
        return View(new Employee());
    }

    [HttpPost]
    public IActionResult Update([FromServices] EmpDbContext site, Employee input)
    {
       
            // var emp1 = site.Employees.Find(u => u.Id == input.Id);
            // emp1.sal = input.sal;

            var emp = site.Employees.First(u => u.Id == input.Id);
            emp.sal=input.sal;
    
            site.SaveChanges();
            return RedirectToAction("RegisterE");
            //return NotFound();
       
    }


    public IActionResult Department([FromServices] EmpDbContext site) 
    {
        var selection = from dept in site.Departments
                        select new DeptInfo 
                        {
                            Deptno = dept.deptno,
                            DName = dept.dname,
                            DLocation = dept.loc,
                            
                        };
        return View(selection.ToList()); 
    }
    

}


