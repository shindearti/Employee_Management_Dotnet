// using System.ComponentModel.DataAnnotations;
// using System.ComponentModel.DataAnnotations.Schema;

// namespace DemoApp.Models;

// public class Department
// {
//     [Key]
//     public int deptno { get; set; }

//     public string dname { get; set; }

//     public string loc { get; set; }

//      public List<Employee> Employeess { get; set; } = new();

// }
