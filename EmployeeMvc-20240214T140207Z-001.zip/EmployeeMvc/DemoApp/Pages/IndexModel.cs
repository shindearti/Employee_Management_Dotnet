using System.Security.Claims;
//using DemoApp.M;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

using DemoApp.Models;
namespace DemoApp.Pages;

public class IndexModel : PageModel
{
    private readonly EmpDbContext shop;

    [BindProperty]
    public Admin Input { get; set; }

    public IndexModel(EmpDbContext db) => shop = db;

    public void OnGet()
    {
        Input = new Admin();
    }

    public async Task<IActionResult> OnPost()
    {
        if(ModelState.IsValid)
        {
        var customer = await shop.Admins.FindAsync(Input.Username);
        if(customer?.Password == Input.Password)
        {
            var identity = new ClaimsIdentity("Admin");
            identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, Input.Username));
            await HttpContext.SignInAsync(new ClaimsPrincipal(identity));
            return RedirectToAction("Display2");
        }
        }
        ModelState.AddModelError("Login", "Invalid Admin ID or Password");
        
        return Page();
    }

}