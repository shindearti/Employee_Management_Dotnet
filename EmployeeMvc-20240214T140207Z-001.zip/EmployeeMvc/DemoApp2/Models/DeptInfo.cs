namespace DemoApp.Models;

public readonly record struct DeptInfo(string Deptno, string DName, string DLocation);
