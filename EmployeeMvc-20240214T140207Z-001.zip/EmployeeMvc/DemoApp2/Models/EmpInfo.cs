namespace DemoApp.Models;

public readonly record struct EmpInfo(string EId, string EName, string ESalary, string EAge,string DeptId);
